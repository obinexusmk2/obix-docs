/* Draft 0.2.1 executable proof:
   (a) Action(state, payload, props) enforces limitSeconds
   (b) Adapter Equivalence across Data / Functional / OOP / Reactive        */

const deepFreeze = (o) => {
  if (o && typeof o === "object") { Object.values(o).forEach(deepFreeze); Object.freeze(o); }
  return o;
};

/* ---------------- TimerDOP: the canonical artifact ---------------- */

const props = deepFreeze({ label: "Timer", limitSeconds: 5, idleText: "Ready" });
const initialState = deepFreeze({ seconds: 0, running: false });

const actions = {
  Start(state) { if (state.running) return state; return { ...state, running: true }; },
  Stop(state)  { if (!state.running) return state; return { ...state, running: false }; },
  Reset(state) { return { ...state, seconds: 0, running: false }; },
  Tick(state, _payload, props) {                     // ← props, third parameter
    if (!state.running) return state;
    if (state.seconds >= props.limitSeconds) return state;   // ← the fix
    return { ...state, seconds: state.seconds + 1 };
  },
  SetLabelSeconds(state, payload) { return { ...state, seconds: payload }; }
};

const derived = {
  formattedTime({ seconds }) {
    const m = Math.floor(seconds / 60), r = seconds % 60;
    return `${String(m).padStart(2,"0")}:${String(r).padStart(2,"0")}`;
  },
  statusLabel({ running, seconds }, { idleText }) {
    if (running) return "Running";
    if (seconds > 0) return "Paused";
    return idleText;
  },
  atLimit({ seconds }, { limitSeconds }) { return seconds >= limitSeconds; }
};

const validation = {
  props: {}, state: { seconds: { type: "number", min: 0 } },
  rules: { NeverPastLimit: { when: ({seconds}, {limitSeconds}) => seconds > limitSeconds,
                             message: "seconds exceeded limitSeconds" } }
};

function validate(state, p) {
  const violations = [];
  for (const [name, r] of Object.entries(validation.rules))
    if (r.when(state, p)) violations.push({ rule: name, message: r.message });
  return { valid: violations.length === 0, violations };
}

const render = (s, p) =>
  `<output role="timer">${derived.formattedTime(s,p)}</output>` +
  `<p>${derived.statusLabel(s,p)}</p>` +
  (derived.atLimit(s,p) ? `<p class="Timer__hint">Maximum duration reached.</p>` : ``);

const TimerDOP = deepFreeze({
  name: "Timer", initialState, props, actions, derived, validation, render, validate
});

/* ---------------- the four adapters ---------------- */

const toData = (dop) => dop;

const toFunctional = (dop) => {
  const reduce = (state, name, payload, p = dop.props) => dop.actions[name](state, payload, p);
  return Object.freeze({
    ...dop, reduce,
    replay: (trace, from = dop.initialState, p = dop.props) =>
      trace.reduce((s, [n, pay]) => reduce(s, n, pay, p), from),
    create(o = {}) {
      let cur = o.state ?? dop.initialState;
      const p = Object.freeze({ ...dop.props, ...(o.props||{}) });
      return { getState: () => cur,
               dispatch(n, pay) { cur = reduce(cur, n, pay, p); return cur; },
               render: () => dop.render(cur, p), validate: () => dop.validate(cur, p) };
    }
  });
};

const toOOP = (dop) => {
  class C {
    #s; #p;
    constructor(o = {}) { this.#s = o.state ?? dop.initialState;
                          this.#p = Object.freeze({ ...dop.props, ...(o.props||{}) }); }
    get state(){ return this.#s; } get props(){ return this.#p; }
    set state(_) { throw new TypeError("[OBIX] Timer.state is read-only"); }
    dispatch(n, pay) { this.#s = dop.actions[n](this.#s, pay, this.#p); return this.#s; }
    replay(t) { for (const [n, pay] of t) this.dispatch(n, pay); return this.#s; }
    render(){ return dop.render(this.#s, this.#p); }
    validate(){ return dop.validate(this.#s, this.#p); }
  }
  for (const n of Object.keys(dop.actions))
    Object.defineProperty(C.prototype, n, { value(pay){ return this.dispatch(n, pay); } });
  for (const d of Object.keys(dop.derived))
    Object.defineProperty(C.prototype, d, { get(){ return dop.derived[d](this.state, this.props); } });
  return C;
};

const toReactive = (dop) => (o = {}) => {
  let cur = o.state ?? dop.initialState;
  const p = Object.freeze({ ...dop.props, ...(o.props||{}) });
  const subs = new Set();
  const dispatch = (n, pay) => {
    const prev = cur, next = dop.actions[n](prev, pay, p);
    if (Object.is(next, prev)) return prev;
    cur = next;
    const changed = Object.keys(dop.initialState).filter(k => !Object.is(prev[k], next[k]));
    for (const f of subs) f(next, prev, { action: n, payload: pay, changedKeys: changed });
    return next;
  };
  return { get state(){ return cur; }, dispatch,
           replay(t){ for (const [n,pay] of t) dispatch(n,pay); return cur; },
           subscribe(f){ subs.add(f); return () => subs.delete(f); },
           render: () => dop.render(cur, p), validate: () => dop.validate(cur, p) };
};

/* ---------------- proof ---------------- */

const eq = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const TRACE = [["Start"],["Tick"],["Tick"],["Stop"]];

const D = toData(TimerDOP), F = toFunctional(TimerDOP),
      O = toOOP(TimerDOP),  R = toReactive(TimerDOP);

// Data (caller threads state and props itself)
let ds = D.initialState;
for (const [n,pay] of TRACE) ds = D.actions[n](ds, pay, D.props);

const results = {
  data:            ds,
  functional:      F.replay(TRACE),
  "functional.create": (() => { const i = F.create();
                          for (const [n,p] of TRACE) i.dispatch(n,p); return i.getState(); })(),
  oop:             new O().replay(TRACE),
  reactive:        R().replay(TRACE)
};

console.log("=== Adapter Equivalence: Start -> Tick -> Tick -> Stop ===");
for (const [k,v] of Object.entries(results)) console.log(String(k).padEnd(20), JSON.stringify(v));
const all = Object.values(results);
console.log("all equivalent      :", all.every(v => eq(v, all[0])));
console.log("expected            :", JSON.stringify({ seconds: 2, running: false }));
console.log("matches expectation :", eq(all[0], { seconds: 2, running: false }));

// derived + render + validation equivalence
const fin = all[0];
console.log("\nrender equivalent   :",
  [D.render(fin,D.props), F.render(fin,F.props),
   new O({state:fin}).render(), R({state:fin}).render()].every(h => h === D.render(fin,D.props)));
console.log("validation equal    :",
  [D.validate(fin,D.props), new O({state:fin}).validate(), R({state:fin}).validate()]
    .every(v => eq(v, D.validate(fin,D.props))));

// step-wise equivalence
let s1 = D.initialState; const oi = new O(), ri = R(), fi = F.create();
let stepOK = true;
for (const [n,pay] of TRACE) {
  s1 = D.actions[n](s1, pay, D.props);
  const step = [s1, fi.dispatch(n,pay), oi.dispatch(n,pay), ri.dispatch(n,pay)];
  if (!step.every(v => eq(v, s1))) stepOK = false;
}
console.log("step-wise equivalent:", stepOK);

// props reach actions: limit enforcement
console.log("\n=== limitSeconds = 5 enforced through props (correction 4) ===");
let ls = D.initialState;
ls = D.actions.Start(ls, undefined, D.props);
for (let i = 0; i < 8; i++) ls = D.actions.Tick(ls, undefined, D.props);
console.log("after Start + 8 Tick:", JSON.stringify(ls));
console.log("atLimit             :", D.derived.atLimit(ls, D.props));
console.log("validation          :", JSON.stringify(D.validate(ls, D.props)));
console.log("render tail         :", D.render(ls, D.props).slice(-58));

// same through every adapter
const LIMIT = [["Start"],...Array(8).fill(["Tick"])];
console.log("oop / reactive / fn :",
  JSON.stringify(new O().replay(LIMIT)), JSON.stringify(R().replay(LIMIT)),
  JSON.stringify(F.replay(LIMIT)));

// payload path
console.log("\n=== payload (single value) ===");
console.log("SetLabelSeconds(42) :", JSON.stringify(new O().dispatch("SetLabelSeconds", 42)));
